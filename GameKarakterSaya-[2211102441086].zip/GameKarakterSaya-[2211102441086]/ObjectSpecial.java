import greenfoot.*;

public class ObjectSpecial extends Actor {
    private GreenfootSound collectSound = new GreenfootSound("sounds.wav");

    public ObjectSpecial() {
        setImage("object.png");
    }

    public void act() {
        moveDown();
        checkForCollision();
    }

    public void moveDown() {
        // Pergerakan ObjectSpecial ke bawah
        setLocation(getX(), getY() + 1);

        // Saat mencapai batas bawah layar, hapus ObjectSpecial
        if (getY() >= getWorld().getHeight() - 1) {
            if (getWorld() != null) {
                getWorld().removeObject(this);
            }
        }
    }

    public void checkForCollision() {
        Character character = (Character) getOneIntersectingObject(Character.class);
        if (character != null) {
            character.increaseScore();
            if (getWorld() != null) {
                getWorld().removeObject(this);
            }
            playCollectSound(); // Memainkan efek suara
        }
    }

    public void playCollectSound() {
        collectSound.play();
    }
}