import greenfoot.*;

public class Enemy extends Actor {
    private int speed = 4; // Kecepatan pergerakan musuh
    private int proximity = 40; // Jarak minimum yang diperlukan untuk "Game Over"

    public Enemy() {
        setImage("enemy.png");
    }

    public void act() {
        Character character = (Character) getWorld().getObjects(Character.class).get(0); // Dapatkan referensi ke Character

        if (character != null) {
            followCharacter(character);
            // Periksa jarak antara Enemy dan Character
            if (getDistance(character) <= proximity) {
                // Musuh menyentuh Character dalam jarak yang ditentukan
                getWorld().showText("Game Over You Lose!", getWorld().getWidth() / 2, getWorld().getHeight() / 2);
                Greenfoot.stop();
            }
        }
    }

    private void followCharacter(Character character) {
        int targetX = character.getX();
        int targetY = character.getY();
        int deltaX = targetX - getX();
        int deltaY = targetY - getY();

        if (Math.abs(deltaX) > 1 || Math.abs(deltaY) > 1) {
            double angle = Math.atan2(deltaY, deltaX);
            int moveX = (int) (speed * Math.cos(angle));
            int moveY = (int) (speed * Math.sin(angle));

            setLocation(getX() + moveX, getY() + moveY);
        }
    }

    private int getDistance(Character character) {
        int deltaX = character.getX() - getX();
        int deltaY = character.getY() - getY();
        return (int) Math.sqrt(deltaX * deltaX + deltaY * deltaY);
    }
}
